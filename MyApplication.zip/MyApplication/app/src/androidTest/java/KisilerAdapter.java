import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myapplication.Kisiler;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class KisilerAdapter extends BaseAdapter {
private LayoutInflater inflater;
private ArrayList<Kisiler> kisilers;
public KisilerAdapter(Activity activity,ArrayList<Kisiler> kisilers){
    this.inflater=(LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    this.kisilers=kisilers;
}
@Override
    public int getCount()
{
    return kisilers.size();
}
    @Override
    public Object getItem(int position)
    {
        return kisilers.get(position);
    }
    @Override
    public long getItemId(int position)
    {
        return position;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        convertView=inflater.inflate(R.layout.kisi,null);
        TextView kisiad=(TextView)convertView.findViewById(R.id.isim);

    }
}
