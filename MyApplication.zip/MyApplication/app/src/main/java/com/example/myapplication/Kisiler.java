package com.example.myapplication;

public class Kisiler {
    private String isim;
    private String numara;

    public void set_isim(String isim)
    {
        this.isim=isim;
    }
    public String get_isim()
    {
        return isim;
    }
    public void set_numara(String numara)
    {
        this.numara=numara;
    }
    public String set_numara()
    {
        return numara;
    }
}
