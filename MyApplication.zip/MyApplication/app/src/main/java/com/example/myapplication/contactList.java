package com.example.myapplication;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class contactList extends AppCompatActivity {
public static final int REQUEST_READ_CONTACTS=1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)== PackageManager.PERMISSION_GRANTED)
        {
            ArrayList<Kisiler> kisiler=new ArrayList<Kisiler>();
            Cursor guide=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,null,null,null, null);
            while(guide.moveToNext())
            {
                String isim=guide.getString(guide.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String numara=guide.getString(guide.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                String contactID=guide.getString(guide.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
                Kisiler r_n=new Kisiler();
                r_n.set_isim(isim);
                r_n.set_numara(numara);
                kisiler.add(r_n);
            }
            guide.close();
        }
        else
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_CONTACTS},REQUEST_READ_CONTACTS);
    }

}