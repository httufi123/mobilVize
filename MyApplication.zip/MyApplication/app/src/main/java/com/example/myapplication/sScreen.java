package com.example.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class sScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sscreen);

        Thread redirect = new Thread() {
            @Override
            public void run() {
                try {
                    sleep(2000);
                    Intent a = new Intent(getApplicationContext(), contactList.class);
                    startActivity(a);
                    finish();
                    super.run();
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }
            }
        };
        redirect.start();
    }


}

